# Travel Budget Explorer

Reverse budget search for flights: enter your departure city, date, and budget — get a list of destinations you can afford.

## Quickstart
```bash
# Extract
tar -xzvf travel-budget-explorer.tar.gz
cd travel-budget-explorer

# Install
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run
python3 app.py
```

Open [http://localhost:5000](http://localhost:5000) in your browser.

## License
MIT